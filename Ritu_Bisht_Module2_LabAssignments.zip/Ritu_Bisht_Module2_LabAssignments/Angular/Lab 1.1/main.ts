import {Smartphone} from './smartPhone';
import {Basicphone} from './basicPhone';
var arry = new Array();
var basicph = new Basicphone("Keypad");
arry.push(basicph);

var smartph = new Smartphone("Without keypad");
arry.push(smartph);

for(var i=0;i<arry.length;i++)
{
    arry[i].printMobileDetails();
}

